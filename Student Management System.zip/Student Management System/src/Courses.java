import javafx.scene.control.CheckBox;
import javafx.scene.control.TextField;

public class Courses {
	private String nameString;
	private double mid;
	private double sessional;
	private double Final;
	private double total;
	 int present=0;
	 int absent=0;
	
	CheckBox check_present;
	CheckBox check_absent;
	
	TextField mid_textfield;
	TextField final_textfield;
	TextField sessional_textfield;
	Courses(){
		mid_textfield = new TextField();
		final_textfield = new TextField();
		sessional_textfield = new TextField();
		check_present = new CheckBox();
		check_absent = new CheckBox();
		mid=0;
		sessional=0;
		Final=0;
		total=0;
		
	}
	public int getPresent() {
		return present;
	}
	public void setPresent(int present) {
		this.present = present;
	}
	public int getAbsent() {
		return absent;
	}
	public void setAbsent(int absent) {
		this.absent = absent;
	}
	
	public String getNameString() {
		return nameString;
	}
	public void setNameString(String nameString) {
		this.nameString = nameString;
	}
	public double getMid() {
		return mid;
	}
	public void setMid(double mid) {
		this.mid = mid;
	}
	public double getSessional() {
		return sessional;
	}
	public void setSessional(double sessional) {
		this.sessional = sessional;
	}
	public double getFinal() {
		return Final;
	}
	public void setFinal(double final1) {
		Final = final1;
	}
	
	public double getTotal() {
		return mid+Final+sessional; 
	}

}
