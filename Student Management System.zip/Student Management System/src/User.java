import java.util.ArrayList;

import javafx.scene.control.CheckBox;

public class User {

	private String nameString;
	private String emailString;
	private String passString;
	private String ageString;
	private String genderString;
	private String regString;
	private String typeString;
	

	public String getTypeString() {
		return typeString;
	}
	public void setTypeString(String typeString) {
		this.typeString = typeString;
	}
	ArrayList<Courses> courseslistArrayList; 
	User(){
		
		courseslistArrayList= new ArrayList<Courses>();
		Courses englishCourses = new Courses();
		englishCourses.setNameString("English");
		Courses mathCourses = new Courses();
		mathCourses.setNameString("Math");
		Courses computerCourses = new Courses();
		computerCourses.setNameString("Computer");
		Courses scienceCourses = new Courses();
		scienceCourses.setNameString("Science");
		courseslistArrayList.add(scienceCourses);
		courseslistArrayList.add(englishCourses);
		courseslistArrayList.add(computerCourses);
		courseslistArrayList.add(mathCourses);
	}
	public String getNameString() {
		return nameString;
	}
	public void setNameString(String nameString) {
		this.nameString = nameString;
	}
	public String getEmailString() {
		return emailString;
	}
	public void setEmailString(String emailString) {
		this.emailString = emailString;
	}
	public String getPassString() {
		return passString;
	}
	public void setPassString(String passString) {
		this.passString = passString;
	}

	public String getAgeString() {
		return ageString;
	}
	public void setAgeString(String ageString) {
		this.ageString = ageString;
	}
	public String getGenderString() {
		return genderString;
	}
	public void setGenderString(String genderString) {
		this.genderString = genderString;
	}
	public String getRegString() {
		return regString;
	}
	public void setRegString(String regString) {
		this.regString = regString;
	}
	
}
