import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Home extends Application {

	public static void main(String[] args) {
		launch(args);
	}
//users
	
	ArrayList<User> userlist = new ArrayList<>(5);
	ArrayList<Teacher> teacherlist = new ArrayList<>(3);
	int userindex=0;
	int teacherindex=0;
	//Register View
	Pane register_pane = new Pane();
	Label register_label = new Label();
	TextField id_textfield = new TextField();
	Label id_text = new Label("Registration ID");
	TextField name_textfield = new TextField();
	Label name_text = new Label("Name");
	TextField email_textfield = new TextField();
	Label email_text = new Label("Email");
	PasswordField password_passwordfield = new PasswordField();
	Label password_text = new Label("Password");
	ToggleGroup gender = new ToggleGroup();
	Label gender_text = new Label("Gender");
	RadioButton male_radio = new RadioButton("Male");
	RadioButton female_radio = new RadioButton("Female");
	DatePicker bday = new DatePicker(); 
	Label age_text = new Label("Age");
	ComboBox<String> Type_combobox ;
	Label type_text = new Label("Type");
	Button register_button = new Button("Register");
	Scene register_Scene ;
	
	
	
	Stage  mainstage = new Stage(); 
	@Override
	public void start(Stage stage) throws Exception {
		// TODO Auto-generated method stub
		User user1 = new User();
		user1.setEmailString("faizanali2000@gmail.com");
		user1.setNameString("Faizan");
		user1.setPassString("123456");
		user1.setTypeString("student");
		//user2
		User user2 = new User();
		user2.setEmailString("rohma@gmail.com");
		user2.setNameString("Rohma Khan");
		user2.setPassString("123456");
		user2.setTypeString("student");
		Teacher tea = new Teacher();
		tea.setEmailString("abcd@gmail.com");
		tea.setPassString("123456");
		tea.setTypeString("teacher");
		tea.setCourse("Math");
		userlist.add(user1);
		userlist.add(user2);
		teacherlist.add(tea);
		Register_view();
		mainstage.setScene(Login_View());
		mainstage.show();
		
		
	}
	User user ;
	void Register_view() {
		String [] combo_list = {"Student","Teacher"};
		Type_combobox = new ComboBox<String>(FXCollections.observableArrayList(combo_list));
		register_label.setText("REGISTRATION");
		register_label.setStyle("-fx-font-size:40px; -fx-text-fill: #f5f6fa;");
		HBox header = new HBox(10);
		header.setPadding(new Insets(0,0,0,20));
		HBox id_hbox = new HBox(10); 
		id_text.setStyle("-fx-text-fill: #f5f6fa;");
		id_hbox.getChildren().addAll(id_text,id_textfield);
		HBox name_hbox = new HBox(56); 
		name_hbox.getChildren().addAll(name_text,name_textfield);
		name_text.setStyle("-fx-text-fill: #f5f6fa;");
		HBox email_hbox = new HBox(58); 
		email_text.setStyle("-fx-text-fill: #f5f6fa;");
		email_hbox.getChildren().addAll(email_text,email_textfield);
		HBox password_hbox = new HBox(36); 
		password_text.setStyle("-fx-text-fill: #f5f6fa;");
		password_hbox.getChildren().addAll(password_text,password_passwordfield);
		HBox age_hbox = new HBox(65); 
		age_text.setStyle("-fx-text-fill: #f5f6fa;");
		age_hbox.getChildren().addAll(age_text,bday);
		HBox gender_hbox = new HBox(45);
		gender_text.setStyle("-fx-text-fill: #f5f6fa;");
		male_radio.setStyle("-fx-text-fill: #f5f6fa;");
		female_radio.setStyle("-fx-text-fill: #f5f6fa;");
		gender_hbox.getChildren().addAll(gender_text,male_radio,female_radio);
		HBox Type_hbox = new HBox(63);
		type_text.setStyle("-fx-text-fill: #f5f6fa;");
		Type_hbox.getChildren().addAll(type_text,Type_combobox);
		header.getChildren().addAll(register_label);
		
		HBox button_hbox = new HBox(10);
		register_button.getStylesheets().add("Style.css");
		register_button.getStyleClass().add("myButton");
		//register button logic
        register_button.setOnAction(e->{
        if(id_textfield.getText().isEmpty() || name_textfield.getText().isEmpty() || email_textfield.getText().isEmpty() || password_passwordfield.getText().isEmpty()) {
        	Alert alert = new Alert(AlertType.ERROR,"Error");
        	alert.show();
        }
        else 
        {
				
				  user= new User();
				  user.setNameString(name_textfield.getText());
				  user.setRegString(id_textfield.getText());
				  user.setEmailString(email_textfield.getText());
				  user.setPassString(password_passwordfield.getText());
				  if(male_radio.isSelected()==true) { System.out.println(male_radio.getText());
				  user.setGenderString(male_radio.getText()); }
				  if(female_radio.isSelected()==true){
				  System.out.println(female_radio.getText());
				  user.setGenderString(female_radio.getText()); }
				  user.setTypeString(Type_combobox.getSelectionModel().getSelectedItem());
				  user.setAgeString(bday.getValue().toString());
				  
				  if(Type_combobox.getSelectionModel().getSelectedItem().equalsIgnoreCase("teacher")) {
					  Teacher te = new Teacher();
					  te.setNameString(name_textfield.getText());
					  te.setRegString(id_textfield.getText());
					  te.setEmailString(email_textfield.getText());
					  te.setPassString(password_passwordfield.getText());
					  if(male_radio.isSelected()==true) { System.out.println(male_radio.getText());
					  te.setGenderString(male_radio.getText()); }
					  if(female_radio.isSelected()==true){
						  te.setGenderString(female_radio.getText()); }
					  te.setTypeString(Type_combobox.getSelectionModel().getSelectedItem());
					  te.setAgeString(bday.getValue().toString());
					  teacherlist.add(te);
				  }
				  else {
				  userlist.add(user);
				  }
				 
        }
        
        });
        
		button_hbox.getChildren().add(register_button);
		button_hbox.setPadding(new Insets(10,10,10,100));
		
		HBox gotologin = new HBox(10);
		Label gotologinlabel = new Label("Already Have an Acccount?");
		Button gotologinbutton = new Button("Login");
		gotologin.getChildren().addAll(gotologinlabel,gotologinbutton);
		gotologin.setLayoutX(500);
		
		VBox component = new VBox(20);
	
	id_textfield.setPromptText("Registration ID");
	name_textfield.setPromptText("Name");
	email_textfield.setPromptText("Email");
	password_passwordfield.setPromptText("Password");
	male_radio.setToggleGroup(gender);
	female_radio.setToggleGroup(gender);
		
		register_pane.setPadding(new Insets(10,10,10,10));
		HBox hb = new HBox(500);
		hb.setPadding(new Insets(150,0,0,350));
		component.getChildren().addAll(header,id_hbox,name_hbox,email_hbox,password_hbox,age_hbox,Type_hbox,gender_hbox,button_hbox,gotologin);
		//component.setAlignment();
		hb.getChildren().add(component);
		//register_pane.getChildren().addAll(component);
	    register_Scene = new Scene(hb,980,680);
	    gotologinbutton.setOnAction(e->{
	    	mainstage.setScene(Login_View());
	    });
	     hb.setStyle("-fx-background-color:#273c75;");
	     
	}
	
	//login view
	Student_window s;
	Teacher_window t;
	Scene Login_View() {

		AnchorPane anchorPane = new AnchorPane();
		anchorPane.setPrefSize(900, 650);
		anchorPane.setStyle("-fx-background-color:#FFFFFF;");
		HBox Header = new HBox();
		Label headerlabel = new Label("IQRA PUBLIC SCHOOL");
		headerlabel.setStyle("-fx-font-size:30px");
		Header.setAlignment(Pos.CENTER);
		Header.getChildren().add(headerlabel);
		Label Login_label = new Label("LOGIN");
		Login_label.setStyle("-fx-font-size:30px; -fx-text-fill:#ecf0f1; -fx-font-family:Raleway Black;");
		VBox leftbox = new VBox();
		leftbox.setPrefSize(400, 650);
		leftbox.getStylesheets().add("Style2.css");
		leftbox.getStyleClass().add("vbox-style");
		
		Image image = new Image("\\images\\logo.png");
		ImageView iView = new ImageView(image);
		leftbox.getChildren().addAll(iView,Login_label);
		leftbox.setAlignment(Pos.CENTER);
		
		
		
		
		//rightside
		
		VBox rightbox = new VBox(10);
		rightbox.getStylesheets().add("Style.css");
		//rightbox.setStyle("-fx-background-color:red;");
		rightbox.setPrefSize(500, 650);
		rightbox.setLayoutX(402);
		HBox emailHBox = new HBox();
		emailHBox.setAlignment(Pos.CENTER);
		TextField email =new TextField();
		email.setPrefSize(200, 30);
		email.setPromptText("Email");
		emailHBox.getChildren().add(email);
		
		HBox passwordhbHBox = new HBox();
		passwordhbHBox.setAlignment(Pos.CENTER);
		PasswordField password = new PasswordField();
		password.setPromptText("Password");
		passwordhbHBox.getChildren().add(password);
		password.setPrefSize(200, 30);
		
		HBox buttonHBox =new HBox();
		Button loginbutton = new Button("Login");
		loginbutton.getStyleClass().add("btn-login");
		loginbutton.setPrefSize(100, 30);
		
		//login logic
		
		try {
		loginbutton.setOnAction(e->{
			for(int x=0; x<userlist.size();x++) {
				if(userlist.get(x).getEmailString().equals(email.getText()) && userlist.get(x).getPassString().equals(password.getText()) && userlist.get(x).getTypeString().equalsIgnoreCase("student") ) {
					userindex=x;
					break;
				}
			}
			for(int x=0; x<teacherlist.size();x++) {
				if(teacherlist.get(x).getEmailString().equals(email.getText()) && teacherlist.get(x).getPassString().equals(password.getText()) && teacherlist.get(x).getTypeString().equalsIgnoreCase("teacher") ) {
					teacherindex=x;
					break;
				}
			}
			
			if(userlist.get(userindex).getEmailString().equals(email.getText()) && userlist.get(userindex).getPassString().equals(password.getText()) && userlist.get(userindex).getTypeString().equalsIgnoreCase("student") )
		{
			
				s=new Student_window(userlist.get(userindex).getNameString(), userlist.get(userindex).getEmailString(), userlist.get(userindex).getRegString(), userlist.get(userindex).getAgeString(), userlist.get(userindex).getGenderString(),userlist.get(userindex).courseslistArrayList,mainstage,Login_View());
				mainstage.setScene(s.Student_Scene());

				}
		else if(teacherlist.get(teacherindex).getEmailString().equals(email.getText()) && teacherlist.get(teacherindex).getPassString().equals(password.getText()) && teacherlist.get(teacherindex).getTypeString().equalsIgnoreCase("teacher") ) {
			t=new Teacher_window(teacherlist.get(teacherindex).getNameString(), teacherlist.get(teacherindex).getEmailString(), teacherlist.get(teacherindex).getRegString(), teacherlist.get(teacherindex).getAgeString(), teacherlist.get(teacherindex).getGenderString(),teacherlist.get(teacherindex).getCourse(),userlist,mainstage,Login_View());
			mainstage.setScene(t.teacher_Scene());

		}
				
				else {
					Alert alert = new Alert(AlertType.ERROR);
					alert.setContentText("NO USER FOUND");
					alert.show();
				}
			});
			
		}
		catch(Exception e) {
			
		}
		buttonHBox.getChildren().addAll(loginbutton);
		buttonHBox.setAlignment(Pos.CENTER);
		buttonHBox.getStylesheets().add("Style2.css");
		
		HBox gotoregister = new  HBox(6);
		Label gotoregister1label= new Label("Don't Have an Account?");
		Button gotoregisterbutton = new Button("SIGN UP");
		gotoregister.setAlignment(Pos.CENTER);
		gotoregister.getStylesheets().add("Style2.css");
		gotoregisterbutton.getStyleClass().add("btn-gotoreg");
		gotoregister.getChildren().addAll(gotoregister1label,gotoregisterbutton);
		rightbox.getChildren().addAll(Header,emailHBox,passwordhbHBox,buttonHBox,gotoregister);
		rightbox.setAlignment(Pos.CENTER);
		
		gotoregisterbutton.setOnAction(e->{
			mainstage.setScene(register_Scene);
			
		});
		anchorPane.getChildren().addAll(leftbox,rightbox);
		Scene scene = new Scene(anchorPane);
		
		return scene;
	}
	
	
}
