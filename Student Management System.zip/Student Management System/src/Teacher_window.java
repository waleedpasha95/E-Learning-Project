import java.util.ArrayList;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Teacher_window {
	private String nameString;
	private String emailString;
	private String registrationid;
	private String ageString;
	private String genderString;
	private String course;
	Stage stage;
	Scene scene;
	private ArrayList<User> studentlist;
	
	public Teacher_window(String nameString, String emailString, String registrationid, String ageString,
			String genderString, String course,ArrayList<User> student,Stage stage,Scene scene) {
		super();
		this.nameString = nameString;
		this.emailString = emailString;
		this.registrationid = registrationid;
		this.ageString = ageString;
		this.genderString = genderString;
		this.course = course;
		this.studentlist = student;
		this.stage = stage;
		this.scene = scene;
	}
	VBox result_vbox;
	HBox update_result_box;
	VBox vbox_right;
	VBox vbox_atttake = new VBox(4);
	public Scene teacher_Scene() {
		
		HBox dashboardBox = new HBox();
		Label dashbLabel = new Label("DASHBOARD");
		dashboardBox.getChildren().add(dashbLabel);
		dashboardBox.setLayoutX(302);
		dashboardBox.setAlignment(Pos.CENTER);
		dashboardBox.setStyle("-fx-background-color:#192a56");
		dashboardBox.setPrefWidth(600);
		dashboardBox.setPrefHeight(90);
		dashbLabel.setStyle("-fx-font-size:25px; -fx-text-fill:#ecf0f1; -fx-font-family:Times new roman;");
		Label label_currentLabel = new Label("Home");
		AnchorPane anchorPane = new AnchorPane();
		anchorPane.setPrefSize(900, 650);
		anchorPane.setStyle("-fx-background-color:#FFFFFF;");
		VBox vBox = new VBox(10);
		vBox.setPrefHeight(650);
		vBox.setPrefWidth(300);
		Image image = new Image("\\images\\logo.png");
		ImageView iView = new ImageView(image);
		HBox header_hbox = new HBox();
		header_hbox.setStyle("-fx-background-color:#192a56;");
		header_hbox.setAlignment(Pos.BASELINE_CENTER);
		Label headerLabel = new Label("IQRA PUBLIC SCHOOL");
		headerLabel.getStyleClass().add("header-style");
		header_hbox.getChildren().addAll(iView);
		Button homeButton = new Button("Home");
		homeButton.setPrefSize(350, 40);
		homeButton.getStyleClass().add("btn");
		Button attendanceButton = new Button("Take Attendance");
		attendanceButton.setPrefSize(350, 40);
		attendanceButton.getStyleClass().add("btn");
		Button resultButton = new Button("Result Update");
		resultButton.setPrefSize(350, 40);
		resultButton.getStyleClass().add("btn");
		Button Logout = new Button("Log Out");
		Logout.setPrefSize(350, 40);
		Logout.getStyleClass().add("btn");
		Logout.setOnAction(e->{
			stage.setScene(scene);
		});
		vBox.getChildren().addAll(header_hbox,homeButton,attendanceButton,resultButton,Logout);
		vBox.getStylesheets().add("Style2.css");
		vBox.getStyleClass().add("vbox-style");
		
		vbox_right = new VBox(3);
		vbox_right.setPrefSize(600, 560);
		vbox_right.setPrefSize(600, 560);
		vbox_right.setLayoutX(301);
		vbox_right.setLayoutY(92);
		vbox_right.setStyle("-fx-background-color:white;");
		vbox_right.setAlignment(Pos.CENTER_LEFT);
		
		VBox vBox_userBox = new VBox(10);
		vBox_userBox.setPrefSize(600, 560);
		vBox_userBox.setLayoutX(301);
		vBox_userBox.setLayoutY(92);
		vBox_userBox.setStyle("-fx-background-color:white;");
		
		
		
		Label reg_idLabel = new Label("Registration ID:");
		Label reg_id = new Label(registrationid);
		Label name_Label = new Label("Name:");
		Label name = new Label(nameString);
		Label email_Label = new Label("Email:");
		Label email = new Label(emailString);
		Label age_Label = new Label("Age:");
		Label age = new Label(ageString);
		Label gender_Label = new Label("Gender:");
		Label gender = new Label(genderString);
		
		HBox reg_Box = new HBox(10);
		reg_Box.getChildren().addAll(reg_idLabel,reg_id);
		reg_Box.setAlignment(Pos.CENTER);
		
		reg_Box.getStylesheets().add("Style2.css");
		reg_idLabel.getStyleClass().add("font-style");
		reg_id.getStyleClass().add("font-style");
		
		HBox nameBox = new HBox(10);
		nameBox.getChildren().addAll(name_Label,name);
		nameBox.setAlignment(Pos.CENTER);

		nameBox.getStylesheets().add("Style2.css");
		name_Label.getStyleClass().add("font-style");
		name.getStyleClass().add("font-style");
		
		HBox emaBox = new HBox(10);
		emaBox.getChildren().addAll(email_Label,email);
		emaBox.setAlignment(Pos.CENTER);
		
		emaBox.getStylesheets().add("Style2.css");
		email_Label.getStyleClass().add("font-style");
		email.getStyleClass().add("font-style");
		
		HBox ageBox = new HBox(10);
		ageBox.getChildren().addAll(age_Label,age);
		ageBox.setAlignment(Pos.CENTER);

		ageBox.getStylesheets().add("Style2.css");
		age_Label.getStyleClass().add("font-style");
		age.getStyleClass().add("font-style");
		
		HBox genderBox = new HBox(10);
		genderBox.getChildren().addAll(gender_Label,gender);
		genderBox.setAlignment(Pos.CENTER);

		genderBox.getStylesheets().add("Style2.css");
		gender_Label.getStyleClass().add("font-style");
		gender.getStyleClass().add("font-style");
		
		vBox_userBox.getChildren().addAll();
		anchorPane.getChildren().addAll(vBox,dashboardBox,vbox_right);
		homeButton.setOnAction(e->{
			vbox_right.getChildren().clear();
			vbox_right.setAlignment(Pos.CENTER_LEFT);
			vbox_right.getChildren().setAll(reg_Box,nameBox,emaBox,ageBox,genderBox);
		});
		
		//attendance view
		//
		att_take_button();
			///attendance
		
		attendanceButton.setOnAction(e->{
			
			vbox_right.getChildren().clear();
			vbox_right.setAlignment(Pos.TOP_LEFT);
			vbox_right.getChildren().setAll(vbox_atttake);
			
		});
		save_button_action();
		
		HBox header_resultBox = new HBox(5);
		
		//
		HBox studentnameheader = new HBox();
		studentnameheader.setStyle("-fx-border-color:black; -fx-border-radius:2px;");
		studentnameheader.setPrefSize(200, 50);
		Label stnamelabel = new Label("Student");
	
		studentnameheader.setAlignment(Pos.CENTER);
		studentnameheader.getChildren().add(stnamelabel);
		//
		HBox mid_name_header = new HBox();
		mid_name_header.setStyle("-fx-border-color:black; -fx-border-radius:2px;");
		mid_name_header.setPrefSize(130, 50);
		Label midnameLabel = new Label("MID");
		midnameLabel.setStyle("-fx-text-fill:#273c75;");
		mid_name_header.setAlignment(Pos.CENTER);
		mid_name_header.getChildren().add(midnameLabel);
		
		HBox final_name_header = new HBox();
		
		final_name_header.setStyle("-fx-border-color:black; -fx-border-radius:2px;");
		final_name_header.setPrefSize(130, 50);
		Label finalnameLabel = new Label("FINAL");
		finalnameLabel.setStyle("-fx-text-fill:#273c75;");
		final_name_header.setAlignment(Pos.CENTER);
		final_name_header.getChildren().add(finalnameLabel);
		
		HBox sessional_name_header = new HBox();
		sessional_name_header.setStyle("-fx-border-color:black; -fx-border-radius:2px;");
		sessional_name_header.setPrefSize(125, 50);
		Label sessionalnameLabel = new Label("SESSIONAL");
		sessionalnameLabel.setStyle("-fx-text-fill:#273c75;");
		sessional_name_header.setAlignment(Pos.CENTER);
		sessional_name_header.getChildren().add(sessionalnameLabel);
		///view
		HBox update_result_box = new HBox(4);
		result_vbox = new VBox(5);
		result_vbox.setPrefSize(600, 560);
		result_vbox.setPrefSize(600, 560);
		result_vbox.setLayoutX(301);
		result_vbox.setLayoutY(92);
		result_vbox.setStyle("-fx-background-color:white;");
		result_vbox.setAlignment(Pos.TOP_LEFT);
		header_resultBox.getChildren().addAll(studentnameheader,mid_name_header,final_name_header,sessional_name_header);
		result_vbox.getChildren().add(header_resultBox);
		set_result_view();
	
		resultButton.setOnAction(e->{
			vbox_right.getChildren().clear();
			vbox_right.setAlignment(Pos.TOP_LEFT);
			save_button_action();
			vbox_right.getChildren().setAll(result_vbox);
		});
		Scene scene = new Scene(anchorPane);
		return scene;
	}
	
	HBox st_name_box;
	HBox st_mid_box;
	HBox st_final_box;
	HBox st_sessional_box;
	private void set_result_view() {
				for(int x=0;x<studentlist.size();x++)
				{
					for(int y = 0; y<studentlist.get(x).courseslistArrayList.size(); y++) {
						if(studentlist.get(x).courseslistArrayList.get(y).getNameString().equalsIgnoreCase(course)) {
							update_result_box = new HBox(5);
							st_name_box = new HBox();
							st_name_box.setStyle("-fx-border-color:black; -fx-border-radius:2px;");
							  st_name_box.setPrefSize(200, 50);
							Label studentname = new Label(studentlist.get(x).getNameString());
							  st_name_box.setAlignment(Pos.CENTER);
							st_name_box.getChildren().add(studentname);
							//
							 st_mid_box = new HBox();
							st_mid_box.setStyle("-fx-border-color:black; -fx-border-radius:2px;");
							st_mid_box.setPrefSize(130, 50);
							st_mid_box.setAlignment(Pos.CENTER);
							
							studentlist.get(x).courseslistArrayList.get(y).mid_textfield.setPrefSize(130, 50);
							studentlist.get(x).courseslistArrayList.get(y).mid_textfield.setPromptText("Mid");
							st_mid_box.getChildren().add(studentlist.get(x).courseslistArrayList.get(y).mid_textfield);
				
							st_final_box = new HBox();
							st_final_box.setStyle("-fx-border-color:black; -fx-border-radius:2px;");
							st_final_box.setPrefSize(130, 50);
							st_final_box.setAlignment(Pos.CENTER);
							
							studentlist.get(x).courseslistArrayList.get(y).final_textfield.setPrefSize(130, 50);
							studentlist.get(x).courseslistArrayList.get(y).final_textfield.setPromptText("Final");
							st_final_box.getChildren().add(studentlist.get(x).courseslistArrayList.get(y).final_textfield);
							
							st_sessional_box = new HBox();
							st_sessional_box.setStyle("-fx-border-color:black; -fx-border-radius:2px;");
							st_sessional_box.setPrefSize(128, 50);
							st_sessional_box.setAlignment(Pos.CENTER);
							
							studentlist.get(x).courseslistArrayList.get(y).sessional_textfield.setPrefSize(130, 50);
							studentlist.get(x).courseslistArrayList.get(y).sessional_textfield.setPromptText("Sessional");
							st_sessional_box.getChildren().add(studentlist.get(x).courseslistArrayList.get(y).sessional_textfield);
							update_result_box.getChildren().addAll(st_name_box,st_mid_box,st_final_box,st_sessional_box);
							result_vbox.getChildren().add(update_result_box);
							break;
					}
					
					
			}
			
			}
		
		  Button update = new Button("Update");
		  update.setPrefSize(100, 20);
		  update.getStylesheets().add("Style2.css");
		  update.getStyleClass().add("btn-login");
		  result_vbox.getChildren().add(update); 
		  update.setOnAction(e->{ 
			  for(int x=0;x<studentlist.size();x++)
			  { 
				  for(int y = 0;y<studentlist.get(x).courseslistArrayList.size(); y++)
			  {
		  if(studentlist.get(x).courseslistArrayList.get(y).getNameString().equalsIgnoreCase(course)) 
		  {
	
		  int mid =Integer.parseInt(studentlist.get(x).courseslistArrayList.get(y).mid_textfield.getText());
		  int Final =Integer.parseInt(studentlist.get(x).courseslistArrayList.get(y).final_textfield.getText()); 
		  int sessional =Integer.parseInt(studentlist.get(x).courseslistArrayList.get(y).sessional_textfield.getText());
		  studentlist.get(x).courseslistArrayList.get(y).setMid(mid);
		  studentlist.get(x).courseslistArrayList.get(y).setFinal(Final);
		  studentlist.get(x).courseslistArrayList.get(y).setSessional(sessional); 
		  }
		  
		  } 
			  }
		  });

	}

	HBox Att_take_box;
	HBox header_att_box;
	HBox Student_name_box;
	Button save_att;
	private void att_take_button() {
		// TODO Auto-generated method stub
		
		HBox coursenameheader = new HBox();
		coursenameheader.setStyle("-fx-border-color:black; -fx-border-radius:2px;");
		coursenameheader.setPrefSize(300, 50);
		Label coursenameLabel = new Label("COURSE");
	
		coursenameheader.setAlignment(Pos.CENTER);
		coursenameheader.getChildren().add(coursenameLabel);
		//
		HBox Present_header = new HBox();
		Present_header.setStyle("-fx-border-color:black; -fx-border-radius:2px;");
		Present_header.setPrefSize(300, 50);
		Label presentLabel = new Label("Present");
		presentLabel.setStyle("-fx-text-fill:#273c75;");
		Present_header.setAlignment(Pos.CENTER);
		Present_header.getChildren().add(presentLabel);
		
		HBox Absent_header = new HBox();
		
		Absent_header.setStyle("-fx-border-color:black; -fx-border-radius:2px;");
		Absent_header.setPrefSize(300, 50);
		Label absentlabel = new Label("Absent");
		absentlabel.setStyle("-fx-text-fill:#273c75;");
		Absent_header.setAlignment(Pos.CENTER);
		Absent_header.getChildren().add(absentlabel);
	
		///view

		header_att_box = new HBox(5);
		vbox_atttake.setPrefSize(600, 560);
		vbox_atttake.setPrefSize(600, 560);
		vbox_atttake.setLayoutX(301);
		vbox_atttake.setLayoutY(92);
		vbox_atttake.setStyle("-fx-background-color:white;");
		vbox_atttake.setAlignment(Pos.TOP_LEFT);
		header_att_box.getChildren().addAll(coursenameheader,Present_header,Absent_header);
		vbox_atttake.getChildren().add(header_att_box);
		
		for(int x=0;x<studentlist.size();x++)
		{
			for(int y = 0; y<studentlist.get(x).courseslistArrayList.size(); y++) {
				if(studentlist.get(x).courseslistArrayList.get(y).getNameString().equalsIgnoreCase(course)) {
					Att_take_box = new HBox(5);
					Student_name_box = new HBox();
					Student_name_box.setStyle("-fx-border-color:black; -fx-border-radius:2px;");
					Student_name_box.setPrefSize(300, 50);
					Label studentname = new Label(studentlist.get(x).getNameString());
					Student_name_box.setAlignment(Pos.CENTER);
					Student_name_box.getChildren().add(studentname);
					//
					 HBox att_present_check_box = new HBox();
					 att_present_check_box.setStyle("-fx-border-color:black; -fx-border-radius:2px;");
					 att_present_check_box.setPrefSize(300, 50);
					att_present_check_box.setAlignment(Pos.CENTER);
					att_present_check_box.getChildren().add(studentlist.get(x).courseslistArrayList.get(y).check_present);
					
					HBox att_absent_check_box = new HBox();
					
					att_absent_check_box.setStyle("-fx-border-color:black; -fx-border-radius:2px;");
					att_absent_check_box.setPrefSize(300, 50);
					att_absent_check_box.setAlignment(Pos.CENTER);
					att_absent_check_box.getChildren().add(studentlist.get(x).courseslistArrayList.get(y).check_absent);
					
					 
					Att_take_box.getChildren().addAll(Student_name_box,att_present_check_box,att_absent_check_box);
					vbox_atttake.getChildren().addAll(Att_take_box);
			}
			
			
	}
	
	}
		save_att = new Button("Save");
		save_att.setPrefSize(100, 29);
		save_att.getStylesheets().add("Style2.css");
		save_att.getStyleClass().add("btn-login");
		vbox_atttake.getChildren().add(save_att);
		
		
	}
	void save_button_action() {
		save_att.setOnAction(e->{
			
			 System.out.println("inside save");
			for(int x=0;x<studentlist.size();x++)
			{
				for(int y = 0; y<studentlist.get(x).courseslistArrayList.size(); y++) {
			 {
				 boolean isSelected = studentlist.get(x).courseslistArrayList.get(y).check_present.isSelected() ;
				 if(isSelected==true) {
					 studentlist.get(x).courseslistArrayList.get(y).present++;
					 System.out.println("present " + studentlist.get(x).courseslistArrayList.get(y).present);
				 }
				 else if(studentlist.get(x).courseslistArrayList.get(y).check_absent.isSelected()) {
					 studentlist.get(x).courseslistArrayList.get(y).absent++;
				 }
				}
			}
				}
		});
	}
}
