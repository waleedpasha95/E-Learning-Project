import java.io.File;
import java.util.ArrayList;

import javafx.application.Application;
import javafx.beans.binding.Bindings;
import javafx.beans.property.DoubleProperty;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class Student_window {

	private String nameString;
	private String emailString;
	private String registrationid;
	private String ageString;
	private String genderString;
	Stage stage;
	Scene scene;
	
	VBox vbox_right;
	VBox vb_attview = new VBox(5);
	User u1 = new User();
	
	
	ArrayList<Courses> courses = new ArrayList<>();
	public Student_window(String nameString, String emailString, String registrationid, String ageString,
			String genderString,ArrayList<Courses> course,Stage stage,Scene scene) {
		super();
		this.nameString = nameString;
		this.emailString = emailString;
		this.registrationid = registrationid;
		this.ageString = ageString;
		this.genderString = genderString;
		this.courses = course;
		this.stage = stage;
		this.scene = scene;
	}
//courses view 
	HBox coursename;
	HBox mid;
	HBox Final;
	HBox total;
	HBox sessional;
	HBox resultviewbox;
	
	//media items
	FileChooser filechooser;
	File selectedFile;
	VBox media_right;
	HBox components_media;
	Button chooseMedia,play_media,pause_media,stop_media,fast_media,slow_media,reload_media,last_media,start_media;
	MediaPlayer mediaplayer;
	Media media;
	MediaView mediaview;
	String path;
	double speed=1.5;
	void media() {
		
		path = new File("src/video/java.mp4").getAbsolutePath();
		media_right = new VBox(5);
		media_right.setPrefSize(600, 560);
		media_right.setPrefSize(600, 560);
		media_right.setLayoutX(301);
		media_right.setLayoutY(92);
		media_right.setStyle("-fx-background-color:white;");
		media_right.setAlignment(Pos.TOP_LEFT);
		chooseMedia = new Button("Select media");
		chooseMedia.getStyleClass().add("btn-login");
		chooseMedia.setOnAction(e->{
			
			filechooser = new FileChooser();
			selectedFile = filechooser.showOpenDialog(null);
			try {
			if(selectedFile !=null) {
				mediaplayer.stop();
				media_right.getChildren().remove(mediaview);
				media_right.getChildren().remove(components_media);
				path = new File(selectedFile.getPath()).getAbsolutePath();
				media = new Media(new File(path).toURI().toString());
				mediaplayer = new MediaPlayer(media);
				mediaview = new MediaView();
				mediaview.setMediaPlayer(mediaplayer);
				mediaplayer.play();
				media_right.getChildren().addAll(mediaview,components_media);
				
			}else {
				Alert a = new Alert(AlertType.ERROR,"File not found");
				a.show();
			}}catch(Exception eee) {
				media();
				Alert error = new Alert(AlertType.ERROR,eee.getMessage());
				error.show();
			}
		});		
		media = new Media(new File(path).toURI().toString());
		mediaplayer = new MediaPlayer(media);
		mediaview = new MediaView();
		mediaview.setMediaPlayer(mediaplayer);
		mediaplayer.setAutoPlay(false);
		media_right.getChildren().add(mediaview);
		/*
		 * DoubleProperty width = mediaview.fitWidthProperty(); DoubleProperty height =
		 * mediaview.fitHeightProperty();
		 * width.bind(Bindings.selectDouble(mediaview.sceneProperty(),"width"));
		 * height.bind(Bindings.selectDouble(mediaview.sceneProperty(),"height"));
		 */
		
		components_media = new HBox(5);
		components_media.getStylesheets().add("Style2.css");
		play_media = new Button("Play");
		play_media.getStyleClass().add("btn-login");
		play_media.setOnAction(e->{
			mediaplayer.play();
		});
		stop_media = new Button("stop");
		stop_media.getStyleClass().add("btn-login");
		stop_media.setOnAction(e->{
			mediaplayer.stop();
		});
		pause_media = new Button("pause");
		pause_media.getStyleClass().add("btn-login");
		pause_media.setOnAction(e->{
			mediaplayer.pause();
		});
		fast_media = new Button("fast");
		fast_media.getStyleClass().add("btn-login");
		fast_media.setOnAction(e->{
			mediaplayer.setRate(speed+=.5);
		});
		slow_media = new Button("slow");
		slow_media.getStyleClass().add("btn-login");
		slow_media.setOnAction(e->{
			mediaplayer.setRate(speed-=.5);
		});
		reload_media = new Button("reload");
		reload_media.getStyleClass().add("btn-login");
				reload_media.setOnAction(e->{
			mediaplayer.seek(mediaplayer.getStartTime());
			mediaplayer.play();
		});
				
		start_media = new Button("Start");
		start_media.getStyleClass().add("btn-login");
		start_media.setOnAction(e->{
	    mediaplayer.seek(mediaplayer.getStartTime());
	    mediaplayer.stop();
		});
		last_media = new Button("last");
		last_media.getStyleClass().add("btn-login");
		last_media.setOnAction(e->{
	    mediaplayer.seek(mediaplayer.getTotalDuration());
	    mediaplayer.stop();
		});
		
		components_media.getChildren().addAll(chooseMedia,play_media,stop_media,pause_media,fast_media,slow_media,reload_media,start_media,last_media);
		media_right.getChildren().add(components_media);
		}
	
	Scene Student_Scene() {
		
		
		
		HBox dashboardBox = new HBox();
		Label dashbLabel = new Label("DASHBOARD");
		dashboardBox.getChildren().add(dashbLabel);
		dashboardBox.setLayoutX(302);
		dashboardBox.setAlignment(Pos.CENTER);
		dashboardBox.setStyle("-fx-background-color:#192a56");
		dashboardBox.setPrefWidth(600);
		dashboardBox.setPrefHeight(90);
		dashbLabel.setStyle("-fx-font-size:25px; -fx-text-fill:#ecf0f1; -fx-font-family:Times new roman;");
		Label label_currentLabel = new Label("Home");
		AnchorPane anchorPane = new AnchorPane();
		anchorPane.setPrefSize(900, 650);
		anchorPane.setStyle("-fx-background-color:#FFFFFF;");
		VBox vBox = new VBox(10);
		vBox.setPrefHeight(650);
		vBox.setPrefWidth(300);
		Image image = new Image("\\images\\logo.png");
		ImageView iView = new ImageView(image);
		HBox header_hbox = new HBox();
		header_hbox.setStyle("-fx-background-color:#192a56;");
		header_hbox.setAlignment(Pos.BASELINE_CENTER);
		Label headerLabel = new Label("IQRA PUBLIC SCHOOL");
		headerLabel.getStyleClass().add("header-style");
		header_hbox.getChildren().addAll(iView);
		Button homeButton = new Button("Home");
		homeButton.setPrefSize(350, 40);
		homeButton.getStyleClass().add("btn");
		Button attendanceButton = new Button("Attendance");
		attendanceButton.setPrefSize(350, 40);
		attendanceButton.getStyleClass().add("btn");
		Button resultButton = new Button("Result");
		resultButton.setPrefSize(350, 40);
		resultButton.getStyleClass().add("btn");
		Button Media = new Button("Media");
		Media.setPrefSize(350, 40);
		Media.getStyleClass().add("btn");
		//media button
		media();
		Media.setOnAction(e->{
			vbox_right.getChildren().clear();
			vbox_right.setAlignment(Pos.TOP_LEFT);
			vbox_right.getChildren().setAll(media_right);
		});
		Button logout = new Button("Log Out");
		logout.setPrefSize(350, 40);
		logout.getStyleClass().add("btn");
		logout.setOnAction(e->{
			stage.setScene(scene);
		});
		vBox.getChildren().addAll(header_hbox,homeButton,attendanceButton,resultButton,Media,logout);
		vBox.getStylesheets().add("Style2.css");
		vBox.getStyleClass().add("vbox-style");
		
		vbox_right = new VBox(3);
		vbox_right.setPrefSize(600, 560);
		vbox_right.setPrefSize(600, 560);
		vbox_right.setLayoutX(301);
		vbox_right.setLayoutY(92);
		vbox_right.setStyle("-fx-background-color:white;");
		vbox_right.setAlignment(Pos.CENTER_LEFT);
		
		VBox vBox_userBox = new VBox(10);
		vBox_userBox.setPrefSize(600, 560);
		vBox_userBox.setLayoutX(301);
		vBox_userBox.setLayoutY(92);
		vBox_userBox.setStyle("-fx-background-color:white;");
		
		
		
		Label reg_idLabel = new Label("Registration ID:");
		Label reg_id = new Label(registrationid);
		Label name_Label = new Label("Name:");
		Label name = new Label(nameString);
		Label email_Label = new Label("Email:");
		Label email = new Label(emailString);
		Label age_Label = new Label("Age:");
		Label age = new Label(ageString);
		Label gender_Label = new Label("Gender:");
		Label gender = new Label(genderString);
		
		HBox reg_Box = new HBox(10);
		reg_Box.getChildren().addAll(reg_idLabel,reg_id);
		reg_Box.setAlignment(Pos.CENTER);
		
		reg_Box.getStylesheets().add("Style2.css");
		reg_idLabel.getStyleClass().add("font-style");
		reg_id.getStyleClass().add("font-style");
		
		HBox nameBox = new HBox(10);
		nameBox.getChildren().addAll(name_Label,name);
		nameBox.setAlignment(Pos.CENTER);

		nameBox.getStylesheets().add("Style2.css");
		name_Label.getStyleClass().add("font-style");
		name.getStyleClass().add("font-style");
		
		HBox emaBox = new HBox(10);
		emaBox.getChildren().addAll(email_Label,email);
		emaBox.setAlignment(Pos.CENTER);
		
		emaBox.getStylesheets().add("Style2.css");
		email_Label.getStyleClass().add("font-style");
		email.getStyleClass().add("font-style");
		
		HBox ageBox = new HBox(10);
		ageBox.getChildren().addAll(age_Label,age);
		ageBox.setAlignment(Pos.CENTER);

		ageBox.getStylesheets().add("Style2.css");
		age_Label.getStyleClass().add("font-style");
		age.getStyleClass().add("font-style");
		
		HBox genderBox = new HBox(10);
		genderBox.getChildren().addAll(gender_Label,gender);
		genderBox.setAlignment(Pos.CENTER);

		genderBox.getStylesheets().add("Style2.css");
		gender_Label.getStyleClass().add("font-style");
		gender.getStyleClass().add("font-style");
		
		vBox_userBox.getChildren().addAll();
		anchorPane.getChildren().addAll(vBox,dashboardBox,vbox_right);
		homeButton.setOnAction(e->{
			vbox_right.getChildren().clear();
			vbox_right.setAlignment(Pos.CENTER_LEFT);
			vbox_right.getChildren().setAll(reg_Box,nameBox,emaBox,ageBox,genderBox);
		});
		
		//attendance view
		//
		att_view_button();
			///attendance
		attendanceButton.setOnAction(e->{
			vbox_right.getChildren().clear();
			vbox_right.setAlignment(Pos.TOP_LEFT);
			vbox_right.getChildren().setAll(vb_attview);
			
		});
		
		//result view items
		
		HBox header_resultBox = new HBox(5);
		
		//
		HBox coursenameheader = new HBox();
		coursenameheader.setStyle("-fx-border-color:black; -fx-border-radius:2px;");
		coursenameheader.setPrefSize(300, 50);
		Label coursenameLabel = new Label("COURSE");
	
		coursenameheader.setAlignment(Pos.CENTER);
		coursenameheader.getChildren().add(coursenameLabel);
		//
		HBox mid_name_header = new HBox();
		mid_name_header.setStyle("-fx-border-color:black; -fx-border-radius:2px;");
		mid_name_header.setPrefSize(50, 50);
		Label midnameLabel = new Label("MID");
		midnameLabel.setStyle("-fx-text-fill:#273c75;");
		mid_name_header.setAlignment(Pos.CENTER);
		mid_name_header.getChildren().add(midnameLabel);
		
		HBox final_name_header = new HBox();
		
		final_name_header.setStyle("-fx-border-color:black; -fx-border-radius:2px;");
		final_name_header.setPrefSize(50, 50);
		Label finalnameLabel = new Label("FINAL");
		finalnameLabel.setStyle("-fx-text-fill:#273c75;");
		final_name_header.setAlignment(Pos.CENTER);
		final_name_header.getChildren().add(finalnameLabel);
		
		HBox sessional_name_header = new HBox();
		sessional_name_header.setStyle("-fx-border-color:black; -fx-border-radius:2px;");
		sessional_name_header.setPrefSize(100, 50);
		Label sessionalnameLabel = new Label("SESSIONAL");
		sessionalnameLabel.setStyle("-fx-text-fill:#273c75;");
		sessional_name_header.setAlignment(Pos.CENTER);
		sessional_name_header.getChildren().add(sessionalnameLabel);
		
		HBox Total_name_header = new HBox();
		Total_name_header.setStyle("-fx-border-color:black; -fx-border-radius:2px;");
		Total_name_header.setPrefSize(100, 50);
		Label TotalnameLabel = new Label("TOTAL");
		TotalnameLabel.setStyle("-fx-text-fill:#273c75;");
		Total_name_header.setAlignment(Pos.CENTER);
		Total_name_header.getChildren().add(TotalnameLabel);
		///view
		
		
		
		VBox vb = new VBox(5);
		vb.setPrefSize(600, 560);
		vb.setPrefSize(600, 560);
		vb.setLayoutX(301);
		vb.setLayoutY(92);
		vb.setStyle("-fx-background-color:white;");
		vb.setAlignment(Pos.TOP_LEFT);
		header_resultBox.getChildren().addAll(coursenameheader,mid_name_header,final_name_header,sessional_name_header,Total_name_header);
		vb.getChildren().add(header_resultBox);
		for(int x=0;x<courses.size();x++)
		{
			resultviewbox = new HBox(5);
			coursename = new HBox();
			coursename.setStyle("-fx-border-color:black; -fx-border-radius:2px;");
			coursename.setPrefSize(300, 50);
			Label coursenamel = new Label(courses.get(x).getNameString());
			coursename.setAlignment(Pos.CENTER);
			coursename.getChildren().add(coursenamel);
			//
			 mid = new HBox();
			 mid.setStyle("-fx-border-color:black; -fx-border-radius:2px;");
			 mid.setPrefSize(50, 50);
			Label midlabel = new Label(Double.toString(courses.get(x).getMid()));
			mid.setAlignment(Pos.CENTER);
			mid.getChildren().add(midlabel);
			
			Final = new HBox();
			
			Final.setStyle("-fx-border-color:black; -fx-border-radius:2px;");
			Final.setPrefSize(50, 50);
			Label finalLabel = new Label(Double.toString(courses.get(x).getFinal()));
			Final.setAlignment(Pos.CENTER);
			Final.getChildren().add(finalLabel);
			
			 sessional = new HBox();
			 sessional.setStyle("-fx-border-color:black; -fx-border-radius:2px;");
			 sessional.setPrefSize(100, 50);
			Label sessionallabel = new Label(Double.toString(courses.get(x).getSessional()));
			sessional.setAlignment(Pos.CENTER);
			sessional.getChildren().add(sessionallabel);
			
			total = new HBox();
			total.setStyle("-fx-border-color:black; -fx-border-radius:2px;");
			total.setPrefSize(100, 50);
			Label Total= new Label(Double.toString(courses.get(x).getTotal()));
			total.setAlignment(Pos.CENTER);
			total.getChildren().add(Total);
			resultviewbox.getChildren().addAll(coursename,mid,Final,sessional,total);
			vb.getChildren().addAll(resultviewbox);
		}
		resultButton.setOnAction(e->{
			vbox_right.getChildren().clear();
			vbox_right.setAlignment(Pos.TOP_LEFT);
			
			vbox_right.getChildren().setAll(vb);
		});
		Scene scene = new Scene(anchorPane);
		return scene;
		
	}
	
	//attandance view method
	
	void att_view_button() {
HBox header_att_box = new HBox(5);
		
		//
		HBox coursenameheader = new HBox();
		coursenameheader.setStyle("-fx-border-color:black; -fx-border-radius:2px;");
		coursenameheader.setPrefSize(300, 50);
		Label coursenameLabel = new Label("COURSE");
	
		coursenameheader.setAlignment(Pos.CENTER);
		coursenameheader.getChildren().add(coursenameLabel);
		//
		HBox Present_header = new HBox();
		Present_header.setStyle("-fx-border-color:black; -fx-border-radius:2px;");
		Present_header.setPrefSize(300, 50);
		Label presentLabel = new Label("Present");
		presentLabel.setStyle("-fx-text-fill:#273c75;");
		Present_header.setAlignment(Pos.CENTER);
		Present_header.getChildren().add(presentLabel);
		
		HBox Absent_header = new HBox();
		
		Absent_header.setStyle("-fx-border-color:black; -fx-border-radius:2px;");
		Absent_header.setPrefSize(300, 50);
		Label absentlabel = new Label("Absent");
		absentlabel.setStyle("-fx-text-fill:#273c75;");
		Absent_header.setAlignment(Pos.CENTER);
		Absent_header.getChildren().add(absentlabel);
	
		///view
		
		
		
		
		vb_attview.setPrefSize(600, 560);
		vb_attview.setPrefSize(600, 560);
		vb_attview.setLayoutX(301);
		vb_attview.setLayoutY(92);
		vb_attview.setStyle("-fx-background-color:white;");
		vb_attview.setAlignment(Pos.TOP_LEFT);
		header_att_box.getChildren().addAll(coursenameheader,Present_header,Absent_header);
		vb_attview.getChildren().add(header_att_box);
		
		for(int x=0;x<courses.size();x++)
		{
			resultviewbox = new HBox(5);
			coursename = new HBox();
			coursename.setStyle("-fx-border-color:black; -fx-border-radius:2px;");
			coursename.setPrefSize(300, 50);
			Label coursenamel = new Label(courses.get(x).getNameString());
			coursename.setAlignment(Pos.CENTER);
			coursename.getChildren().add(coursenamel);
			//
			 HBox att_present = new HBox();
			 att_present.setStyle("-fx-border-color:black; -fx-border-radius:2px;");
			 att_present.setPrefSize(300, 50);
			Label prelabel = new Label(Integer.toString(courses.get(x).getPresent()));
			att_present.setAlignment(Pos.CENTER);
			att_present.getChildren().add(prelabel);
			
			HBox att_absent = new HBox();
			
			att_absent.setStyle("-fx-border-color:black; -fx-border-radius:2px;");
			att_absent.setPrefSize(300, 50);
			Label finalLabel = new Label(Integer.toString(courses.get(x).getAbsent()));
			att_absent.setAlignment(Pos.CENTER);
			att_absent.getChildren().add(finalLabel);
			
			 
			resultviewbox.getChildren().addAll(coursename,att_present,att_absent);
			vb_attview.getChildren().addAll(resultviewbox);
	}
	
	}
}
